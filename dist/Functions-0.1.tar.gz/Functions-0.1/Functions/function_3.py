def date_parser(dates):

    # Split DateTime and Isolate Date
    return [date.split()[0] for date in dates]
